using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Tarea2.Pages
{
    public class ConfirmacionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
