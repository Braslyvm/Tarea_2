using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Tarea2.Pages
{
    public class FormularioModel : PageModel
    {
        private readonly string _connectionString = "Server=BRASLY\\BRASLYMSSQL;Database=usurario;User Id=sa;Password=brasly2004;TrustServerCertificate=True;";


        [BindProperty]
        public int Cedula { get; set; }

        [BindProperty]
        public string Nombre { get; set; }

        [BindProperty]
        public string Apellido1 { get; set; }

        [BindProperty]
        public string Apellido2 { get; set; }

        public List<dynamic> Personas { get; set; }


        public async Task<IActionResult> OnPostAsync()
        {


            string query = "INSERT INTO personas (Cedula, nombre, Apellido1, Apellido2) VALUES (@Cedula, @Nombre, @Apellido1, @Apellido2)";

            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Cedula", Cedula);
                    command.Parameters.AddWithValue("@Nombre", Nombre);
                    command.Parameters.AddWithValue("@Apellido1", Apellido1);
                    command.Parameters.AddWithValue("@Apellido2", Apellido2);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                }

                return Page();
            }
            catch (SqlException ex)
            {
                ModelState.AddModelError("", "No se pudo conectar a la base de datos: " + ex.Message);
                return Page();
            }
        }

    }
     
}

